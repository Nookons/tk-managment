import React from 'react';
import {Divider} from "antd";

const Footer = () => {
    return (
        <Divider>Footer</Divider>
    );
};

export default Footer;