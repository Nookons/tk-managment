import React from 'react';
import {Space} from "antd";
import Button from "antd/es/button";

const Header = () => {
    return (
        <div style={{
            display: 'flex',
            justifyContent: "flex-end"
        }}>
            <Space direction="horizontal">
                <Button type="link">Sign In</Button>
            </Space>
        </div>
    );
};

export default Header;