
export const HOME_ROUTE = "/"
export const SIGN_IN_ROUTE = "/sign-in"