import React from 'react';

const SignIn = () => {
    return (
        <div>
            Sign In page
        </div>
    );
};

export default SignIn;