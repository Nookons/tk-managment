import React from 'react';
import {Divider} from "antd";

const Home = () => {

    return (
        <div>
            <Divider>Home</Divider>
        </div>
    );
};

export default Home;